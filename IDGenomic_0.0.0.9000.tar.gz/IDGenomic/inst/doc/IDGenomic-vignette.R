## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(IDGenomic)

## ---- message = FALSE---------------------------------------------------------
library(SummarizedExperiment)

## ---- fig.width=7, fig.height=5-----------------------------------------------
GSE48762 <- GEOExtract(GEOAccession = "GSE48762",
                       GSEMatrix =TRUE, 
                      getGPL = TRUE,  
                      plots = TRUE, 
                      NSub = 10)


## -----------------------------------------------------------------------------
head(rowData(GSE48762)$Symbol)
head(rowData(GSE48762)$Entrez_Gene_ID)

## -----------------------------------------------------------------------------
table(GSE48762$`blood source:ch1`)

table(GSE48762$`day:ch1`)

table(GSE48762$`ethnicity:ch1`)

table(GSE48762$`gender:ch1`)

table(GSE48762$`vaccine:ch1`)

## ---- fig.width=7, fig.height=5-----------------------------------------------
class(GSE48762)

GSE48762 <- QuantileNorm(GEOdata = GSE48762, plots = TRUE, NSub = 10)

## -----------------------------------------------------------------------------
dim(GSE48762)

gene_overlap <- openxlsx::read.xlsx("/Users/yu.zhang/Desktop/Modular/Data/total_overlap_8.24.xlsx", sheet = 1)$with_U133A
gene_overlap <- gene_overlap[!is.na(gene_overlap)]
length(gene_overlap)

GSE48762.sub <- FeatureFilter(GEOdata = GSE48762, 
                              filterVar = "Symbol",
                              filterValue = gene_overlap,
                              unique = FALSE)
dim(GSE48762.sub)

GSE48762.unique <- FeatureFilter(GEOdata = GSE48762, 
                              filterVar = "Symbol",
                              filterValue = gene_overlap,
                              unique = TRUE)
dim(GSE48762.unique)

# If all unique genes, should return FALSE.
all(duplicated(rowData(GSE48762.unique)$Symbol))

